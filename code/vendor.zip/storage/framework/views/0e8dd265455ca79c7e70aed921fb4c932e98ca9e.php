<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; MAGA 2021 .</strong> All rights reserved.
  </footer>
<?php /**PATH F:\Maga-Works\One_login V4\resources\views/layouts/body_footerlayout.blade.php ENDPATH**/ ?>