<!DOCTYPE html>
<html>
<head>
    <title>Maga Engineering</title>
</head>
<body>
    <h3>Please use above password to login</h3>
    <p>New Password=<?php echo e($password); ?></p>

    <p>Thank you</p>
    <img src="<?php echo e($img); ?>"  width="180" height="50">
</body>
</html>
<?php /**PATH F:\Maga-Works\One_login V4\resources\views/user/emp_password_reset.blade.php ENDPATH**/ ?>