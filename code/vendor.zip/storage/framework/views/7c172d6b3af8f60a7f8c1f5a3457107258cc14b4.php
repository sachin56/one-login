<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- Navbar -->
<nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
    <div class="container">
        <!-- Left navbar links -->


        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">

            <ul class="navbar-nav">
                <?php if(Auth::user()->id == 1): ?>
                <li class="nav-item">
                    <a href="register_user" class="nav-link <?php echo e(Route::current()->getName() == 'register_user' ? 'active' : ''); ?>">Add User</a>
                  </li>
                  <li class="nav-item">
                    <a href="register_system" class="nav-link <?php echo e(Route::current()->getName() == 'register_system' ? 'active' : ''); ?>">Add System</a>
                  </li>
                  <?php endif; ?>
                  <li class="nav-item">
                    <a href="user_systems" class="nav-link <?php echo e(Route::current()->getName() == 'user_systems' ? 'active' : ''); ?>">Systems</a>
                  </li>
                <li class="nav-item dropdown">
                    <a id="dropdownSubMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle"><?php echo e(Auth::user()->name); ?></a>
                    <ul aria-labelledby="dropdownSubMenu1" class="dropdown-menu border-0 shadow">
                      <li><a href="user_profile" class="dropdown-item <?php echo e(Route::current()->getName() == 'user_profile' ? 'active' : ''); ?>">Profile</a></li>
                      <li><a href="#" class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log Out</a></li>
                    </ul>
                </li>
                </ul>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                class="d-none">
                <?php echo csrf_field(); ?>
                </form>
        </ul>




    </div>
</nav>
<!-- /.navbar -->

<!-- Main Sidebar Container -->

<?php /**PATH /home/itmaga/OneLogin/resources/views/layouts/navbarlayout.blade.php ENDPATH**/ ?>