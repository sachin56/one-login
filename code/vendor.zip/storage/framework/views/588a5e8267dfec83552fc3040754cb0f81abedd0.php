<?php echo $__env->make('layouts.headerlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="wrapper">

    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbarlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.navbar -->
    <link rel="stylesheet" href="/css/box_shadow.css">
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <br>
                <div class="card">
                    
                    <!-- /.card-header -->
                    <div class="card-body">
                        <div class="row">
                            <?php $__currentLoopData = $user_systems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $system): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2" >
                                    <div class="box">
                                    <a href="http://<?php echo e($system->domain); ?>/onelogin/<?php echo e(Auth::user()->id); ?>"><img src="attachments/<?php echo e($system->attachment); ?>" style="object-fit:contain; width:100%; height:100%; " alt="<?php echo e($system->system_name); ?>"></a>
                                    <p style="text-align: center;"><strong><?php echo e($system->system_name); ?></strong></p>
                                </div>

                                </div>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <!-- /.card-body -->
                </div>

            </div>
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('layouts.body_footerlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- ./wrapper -->
<?php echo $__env->make('layouts.footerlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript" src="js/formToJson.js"></script>
<script type="text/javascript" src="js/user_systems.js"></script>
<?php /**PATH F:\Maga-Works\User_Login\resources\views/system/user_systems.blade.php ENDPATH**/ ?>