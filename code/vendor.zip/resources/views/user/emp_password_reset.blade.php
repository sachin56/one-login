<!DOCTYPE html>
<html>
<head>
    <title>Maga Engineering</title>
</head>
<body>
    <h3>Please use above password to login</h3>
    <p>New Password={{ $password }}</p>

    <p>Thank you</p>
    <img src="{{ $img }}"  width="180" height="50">
</body>
</html>
