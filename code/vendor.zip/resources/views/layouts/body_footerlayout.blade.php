<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      {{-- Anything you want text --}}
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; MAGA 2021 .</strong> All rights reserved.
  </footer>
